# Pugs::Grammar::Rule - fglock
#
# the 'Rule' grammar - 'rule' is the main rule
#

use Text::Balanced; 

package Pugs::Grammar::Rule;
use strict;
use warnings;
no warnings qw( once redefine );

use Data::Dumper;
use Pugs::Runtime::Rule;
#use Pugs::Runtime::Grammar; -- MOP 

use vars qw( @rule_terms );

use base 'Pugs::Grammar::Base';
use Pugs::Grammar::Rule::Rule;   # compiled with lrep

sub code {
    my $class = shift;
    return $class->no_match unless $_[0];
    my ($extracted,$remainder) = Text::Balanced::extract_codeblock( $_[0] );
    #warn "Testing <code>: #$_[0]#" if $extracted ne '';
    return Pugs::Runtime::Match->new( { 
        bool  => ( $extracted ne '' ),
        match => $extracted,
        tail  => $remainder,
    } );
}

sub literal {
    my $class = shift;
    return $class->no_match unless $_[0];
    my ($extracted,$remainder) = Text::Balanced::extract_delimited( $_[0], "'" );
    $extracted = substr( $extracted, 1, -1 ) if length($extracted) > 1;
    return Pugs::Runtime::Match->new( { 
        bool  => ( $extracted ne '' ),
        match => $extracted,
        tail  => $remainder,
    } );
}

sub metasyntax {
    my $class = shift;
    return $class->no_match unless $_[0];
    my ($extracted,$remainder) = Text::Balanced::extract_bracketed( $_[0], "<..>" );
    $extracted = substr( $extracted, 1, -1 ) if length($extracted) > 1;
    return $class->no_match if $extracted eq '';
    #die Dumper( $extracted );
    return Pugs::Runtime::Match->new( { 
        bool  => 1,
        match => $extracted,
        tail  => $remainder,
        capture => { metasyntax => $extracted },
    } );
}
unshift @rule_terms, 'metasyntax';

    #local $SIG{__WARN__} = sub {};

    # XXX - currying should be made automatically by <@xxx> runtime
    # curry @rule_terms with Grammar
    @rule_terms = map { 
        my $method = $_;
        sub{ 
            # warn "Trying $method\n";
            my $match = Pugs::Grammar::Rule->$method(@_);
            warn "Match '$method' ".Dumper($$match) ;# if $match->{bool};
            return $$match;
        }
    }
    @rule_terms;


1;
