#ifndef _WIN_CONSOLE_H
#define _WIN_CONSOLE_H
#include <windows.h>

BOOL SetPosition(HANDLE h, COORD* c);

#endif
