module Version(package, version, fullName) where

package = "pugs-DrIFT"

version = "2.2.3.0"


fullName = package ++ "-" ++ version
