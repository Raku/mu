void bytewrite(unsigned char *a, int bytes);
unsigned char byteread(unsigned char *a, int bytes);
void wordwrite(unsigned long *a, int bytes);
unsigned int wordread(unsigned long *a, int bytes);
